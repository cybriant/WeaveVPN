import subprocess
bashCommand = "sudo apt-get install openvpn"
process = subprocess.Popen(bashCommand.split(), stdout=subprocess.PIPE)
output, error = process.communicate()
